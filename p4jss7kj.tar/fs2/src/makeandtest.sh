#! /bin/bash

make > makeresults.txt
echo ">>>>>> Beginning Testing <<<<<<<<"
./fs